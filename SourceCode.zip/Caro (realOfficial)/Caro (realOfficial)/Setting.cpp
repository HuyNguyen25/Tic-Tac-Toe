﻿#include "Setting.h"

void ShowSettingBanner() {
	SetTextColor(253);
	UINT oldcp = GetConsoleOutputCP();
	SetConsoleOutputCP(CP_UTF8);

	GotoXY(28, 2);
	cout << u8"███████ ███████ ████████ ████████ ██ ███    ██  ██████  ███████ ";
	GotoXY(28, 3);
	cout << u8"██      ██         ██       ██    ██ ████   ██ ██       ██      ";
	GotoXY(28, 4);
	cout << u8"███████ █████      ██       ██    ██ ██ ██  ██ ██   ███ ███████ ";
	GotoXY(28, 5);
	cout << u8"     ██ ██         ██       ██    ██ ██  ██ ██ ██    ██      ██ ";
	GotoXY(28, 6);
	cout << u8"███████ ███████    ██       ██    ██ ██   ████  ██████  ███████ ";

	SetTextColor(240);
	SetConsoleOutputCP(oldcp);
}

void DrawMusicNote() {
	SetTextColor(240);
	UINT oldcp = GetConsoleOutputCP();
	SetConsoleOutputCP(CP_UTF8);

	GotoXY(2, 10);
	cout << u8"              ██████                 ";
	GotoXY(2, 11);
	cout << u8"              ███████████            ";
	GotoXY(2, 12);
	cout << u8"              ████████████████       ";
	GotoXY(2, 13);
	cout << u8"              ██████████████████     ";
	GotoXY(2, 14);
	cout << u8"              ███     ██████████     ";
	GotoXY(2, 15);
	cout << u8"              ███         ██████     ";
	GotoXY(2, 16);
	cout << u8"              ███                    ";
	GotoXY(2, 17);
	cout << u8"              ███                    ";
	GotoXY(2, 18);
	cout << u8"              ███                    ";
	GotoXY(2, 19);
	cout << u8"              ███                    ";
	GotoXY(2, 20);
	cout << u8"              ███                    ";
	GotoXY(2, 21);
	cout << u8"      █████   ███                    ";
	GotoXY(2, 22);
	cout << u8"  ███████████████                    ";
	GotoXY(2, 23);
	cout << u8"█████████████████                    ";
	GotoXY(2, 24);
	cout << u8"█████████████████                    ";
	GotoXY(2, 25);
	cout << u8"█████████████████                    ";
	GotoXY(2, 26);
	cout << u8"████████████████                     ";
	GotoXY(2, 27);
	cout << u8"████████████                       ";
	GotoXY(2, 28);
	cout << u8"    █████                          ";

	SetConsoleOutputCP(oldcp);
	SetTextColor(240);
}

void ShowSettingTutorial() {
	SetTextColor(243);
	GotoXY(55, 22);
	cout << (char)16 << " A: GO LEFT";
	GotoXY(55, 23);
	cout << (char)16 << " D: GO RIGHT";
	GotoXY(55, 24);
	cout << (char)16 << " ENTER: SELECT";
	GotoXY(49, 25);
	cout << "BACKSPACE: BACK TO MENU";
}

void DrawOnOffButton(int x, int y) {
	SetTextColor(243);
	GotoXY(x, y);
	cout << (char)201;
	for (int i = 0; i < 4; i++) {
		cout << (char)205;
	}
	cout << (char)203;
	
	for (int i = 0; i < 6; i++) {
		cout << (char)205;
	}
	cout << (char)187;
	
	for (int i = 0; i < 1; i++) {
		GotoXY(x, y + 1+i);
		cout << (char)186 << "    " << (char)186 << "      " << (char)186;
	}
	
	GotoXY(x, y + 2);
	cout << (char)200;
	for (int i = 0; i < 4; i++) {
		cout << (char)205;
	}
	cout << (char)202;
	
	for (int i = 0; i < 6; i++) {
		cout << (char)205;
	}
	cout << (char)188;
}

void ShowSettingMenu() {
	system("cls");
	system("color F0");
	DrawMusicNote();
	ShowSettingBanner();
	DrawOnOffButton(65,15);
	ShowSettingTutorial();

	string menu[] = { "ON","OFF"};
	int color[] = { 226,240 };
	int counter = 1;
	char _KEY;
	SetTextColor(243);
	GotoXY(45, 16);
	cout << "BACKGROUND SOUND:";

	for (;;) {
		for (int i = 0; i < 2; i++) {
			SetTextColor(color[i]);
			GotoXY(67+6*i, 16);
			cout << menu[i];
		}
		for (int i = 0; i < 2; i++)
			color[i] = 240;
		GotoXY(119, 30);
		_KEY = toupper(_getch());
		switch (_KEY) {
		case 'A':
			counter--;
			PlaySound(TEXT("Sound/MovingSoundMenu.wav"), NULL, SND_ASYNC);
			if (counter == 0)
				counter = 2;
			break;
		case 'D':
			counter++;
			PlaySound(TEXT("Sound/MovingSoundMenu.wav"), NULL, SND_ASYNC);
			if (counter == 3)
				counter = 1;
			break;
		case 8:
			return;
		case 13:
			PlaySound(TEXT("Sound/TickXOSound.wav"), NULL, SND_ASYNC);
			switch (counter) {
			case 1:
				mciSendString(TEXT("play Sound/BackgroundSound.mp3 repeat"), NULL, 0, NULL);
				break;
			case 2:
				mciSendString(TEXT("stop Sound/BackgroundSound.mp3"), NULL, 0, NULL);
				break;
			}
			break;
		}
		color[counter - 1] = 226;
	}
}
