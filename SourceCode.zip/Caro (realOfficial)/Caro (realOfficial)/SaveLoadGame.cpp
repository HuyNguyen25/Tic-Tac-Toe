﻿#include "SaveLoadGame.h"

static char* StringToChar(string a, char* char_arr) {
	strcpy_s(char_arr,a.length()+1, a.c_str());

	return char_arr;
}

//Save_Duy
bool SaveGame(_POINT** _A, bool* _TURN, int* XScore, int* XStep, int* OScore, int* OStep) {
	string File = UpdateFilesMenu();
	if (File != "") {
		SaveGameState(File, _A, _TURN, XScore, XStep, OScore, OStep);
		return true;
	}
	return false;
}

string UpdateFilesMenu() { // return full file name string 
	const string FilesMenu = "FilesMenu.txt";
	string FileName = "";
	vector<string> FileList;
	FileList.resize(0);

	ifstream fin;
	fin.open(FilesMenu, ios_base::in);

	ReadFileList(fin, FileList);
	if (FileList.size() > 10)
		return FileName;
	if (fin) fin.close();

	FileName = FileNameGenerator();

	FileList.push_back(FileName);
	ofstream fout;
	fout.open(FilesMenu, ios::out);
	WriteFileList(fout, FileList);

	if (fout) fout.close();

	return FileName;
}

string FileNameGenerator() {
	const string extension = ".txt";

	string CurrentTime = TimeGenerator();
	string FileName = CurrentTime;

	return FileName + extension;
}

string TimeGenerator() {
	char str[26];
	time_t rawtime;
	struct tm timeinfo;
	time(&rawtime);
	localtime_s(&timeinfo, &rawtime);
	strftime(str, 26, "%d-%m-%y %H.%M.%S", &timeinfo);
	string res = str;
	return res;
}

void WriteFileList(ofstream& file, vector<string>& FileList) {
	for (int i = 0; i < FileList.size(); i++) {
		if (i == FileList.size() - 1)
			file << FileList[i];
		else file << FileList[i] << "\n";
	}
}

void SaveGameState(string fileName, _POINT** _A, bool* _TURN, int* XScore, int* XStep, int* OScore, int* OStep) {
	ofstream fout;
	fout.open(fileName, ios_base::out);

	//Turn
	SaveCurrentTurn(fout, _TURN);

	//Score + Step
	SaveScoreStep(fout, XScore, XStep);
	SaveScoreStep(fout, OScore, OStep);

	//Board State
	for (int i = 0; i < BOARD_SIZE; i++)
		for (int j = 0; j < BOARD_SIZE; j++)
			SaveEachCell(fout, &_A[i][j]);

	if (fout) fout.close();
}

void SaveCurrentTurn(ofstream& fout, bool* _TURN) {
	fout << *_TURN << endl;
}
void SaveScoreStep(ofstream& fout, int* score, int* step) {
	fout << *score << " " << *step << endl;
}
void SaveEachCell(ofstream& fout, _POINT* _A) {
	fout << _A->x << " " << _A->y << " " << _A->c << "\n";
}

//Load_Huy
void UpdateLoadMenu(vector<string>& menu, string delFile) {
	size_t n = menu.size();
	size_t i = 0;
	for (; i < n; i++)
	{
		if (menu[i] == delFile)
			break;
	}
	for (; i < n-1; i++)
	{
		//menu[i] = "";
		menu[i] = menu[i + 1];
	}
	menu.resize(n - 1);
}
void ReadEachCell(ifstream& fi, _POINT& A) {
	fi >> A.x >> A.y >> A.c;
}
void ReadFileTurn(ifstream& fi, bool& _TURN) {
	fi >> _TURN;
}
void ReadFileScoreStep(ifstream& fi, int& score, int& step) {
	fi >> score >> step;
}
void ReadFileBoard(ifstream& fi, _POINT**& arr,bool &turn, int& xscore, int& xstep, int& oscore, int& ostep) {
	ReadFileTurn(fi, turn);
	ReadFileScoreStep(fi, xscore, xstep);
	ReadFileScoreStep(fi, oscore, ostep);
	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			ReadEachCell(fi, arr[i][j]);
		}
	}
}
void ReadFileList(ifstream& fi, vector<string>& s) {

	s.resize(0);
	string temp;
	while (!fi.eof()) {
		getline(fi, temp);
		s.push_back(temp);
	}
	size_t nFiles = s.size();
	if (s[0] == "") {
		nFiles--;
		//fix lai vector menu de in ra dep hon
		// do phan tu dau tien cua menu la chuoi "" vi the dich tat ca cac phan
		//tu dang sau len sau do resize lai
		for (int i = 0; i < nFiles; i++)
		{
			s[i] = s[i + 1];
		}
		s.resize(nFiles);
	}
}
void DrawLoadBanner() {
	SetTextColor(253);
	UINT oldcp = GetConsoleOutputCP();
	SetConsoleOutputCP(CP_UTF8);
	GotoXY(33, 2);
	cout << u8"██   ██ ██ ███████ ████████  ██████  ██████  ██    ██";
	GotoXY(33, 3);
	cout << u8"██   ██ ██ ██         ██    ██    ██ ██   ██  ██  ██";
	GotoXY(33, 4);
	cout << u8"███████ ██ ███████    ██    ██    ██ ██████    ████ ";
	GotoXY(33, 5);
	cout << u8"██   ██ ██      ██    ██    ██    ██ ██   ██    ██   ";
	GotoXY(33, 6);
	cout << u8"██   ██ ██ ███████    ██     ██████  ██   ██    ██    ";
	SetConsoleOutputCP(oldcp);
	SetTextColor(240);
}
void DrawLoadTutorial() {
	SetTextColor(243);
	GotoXY(55, 22);
	cout << (char)16 << " W: GO UP";
	GotoXY(55, 23);
	cout << (char)16 << " S: GO DOWN";
	GotoXY(55, 24);
	cout << (char)16 << " ENTER: SELECT";
	GotoXY(55, 25);
	cout << (char)16 << " X: DELETE";
	GotoXY(49, 26);
	cout << "BACKSPACE: BACK TO MENU";
	SetTextColor(240);
}

void DrawLoadSymbol() {
	SetTextColor(240);
	UINT oldcp = GetConsoleOutputCP();
	SetConsoleOutputCP(CP_UTF8);

	GotoXY(1, 10);
	cout << u8R"(                                    
                ███                  
                ███          
                ███       
                ███               
           ███  ███  ███          
            ███████████          
              ███████             
                ███              
                                 
                                    
 █████████████████████████████████ 
								      )";

	SetConsoleOutputCP(oldcp);
	SetTextColor(240);
}
void DrawLoadInterface() {
	DrawLoadSymbol();
	DrawLoadBanner();
	DrawLoadTutorial();
}
string ShowLoadMenu() {
	system("cls");
	DrawLoadInterface();
	size_t nFiles=0;
	vector<string>menu;
	vector<int>color;
	string file = "";
	ifstream fi;
	fi.open("FilesMenu.txt", ios::in);
	ReadFileList(fi, menu);

	if (fi) fi.close();

	nFiles = menu.size();

	if (nFiles == 0) {
		SetTextColor(244);
		GotoXY(29, 12);
		cout << "YOUR HISTORY IS EMPTY, PRESS ANY KEY TO GO BACK TO MENU.";
		SetTextColor(240);
		_getch();
		return file;
	}
	
	color.resize(nFiles);
	color[0] = 226;
	for (size_t i = 1; i < nFiles; i++) {
		color[i] = 244;
	}
	int counter = 1;
	char _KEY;
	for (; true;) {

		for (size_t i = 0; i < nFiles; i++) {
			GotoXY(50, 11 + i);
			SetTextColor(color[i]);
			cout << menu[i];
		}
		for (size_t i = 0; i < nFiles; i++)
			color[i] = 244;


		_KEY = toupper(_getch());
		switch (_KEY) {
		case 'W':
			counter--;
			PlaySound(TEXT("Sound/MovingSoundMenu.wav"), NULL, SND_ASYNC);
			if (counter == 0)
				counter = nFiles;
			break;

		case 'S':
			counter++;
			PlaySound(TEXT("Sound/MovingSoundMenu.wav"), NULL, SND_ASYNC);
			if (counter == nFiles + 1)
				counter = 1;
			break;
		case 8:
			return file;	
		case 13:
		{
			PlaySound(TEXT("Sound/TickXOSound.wav"), NULL, SND_ASYNC);
			file = menu[counter - 1];
			return file;
		}
		break;
		case 'X': {
			PlaySound(TEXT("Sound/TickXOSound.wav"), NULL, SND_ASYNC);
			string delFile = menu[counter - 1];
			int len = delFile.length() + 1;
			char* str = new char[len];
			str = StringToChar(delFile, str);
			if (remove(str) == 0) {
				GotoXY(50, 28);
				cout << "Delete " << delFile << " successfully.";
				UpdateLoadMenu(menu, delFile);
				ofstream fout;
				fout.open("FilesMenu.txt", ios::out);
				WriteFileList(fout, menu);
				fout.close();
				system("cls");
				system("color F0");
				DrawLoadInterface();
				file = "";

				ifstream fin;
				fin.open("FilesMenu.txt", ios::in);
				ReadFileList(fin, menu);
				fin.close();

				nFiles = menu.size();
				if (nFiles == 0) {
					SetTextColor(244);
					GotoXY(29, 12);
					cout << "YOUR HISTORY IS EMPTY, PRESS ANY KEY TO GO BACK TO MENU.";
					SetTextColor(240);
					_getch();
					return file;
				}

				color.resize(nFiles);
				color[0] = 226;
				for (size_t i = 1; i < nFiles; i++) {
					color[i] = 244;
				}

				counter=1;
				Sleep(500);
				GotoXY(50, 28);
				cout << "                                                                               ";    
			}
			else {
				GotoXY(50, 28);
				cout << "Can not delete " << delFile;
				Sleep(500);
				GotoXY(50, 28);
				cout << "                                                                               ";
			}
			delete[]str;
		}
			break;
		}
		if(counter>0)
			color[counter - 1] = 226;
	}
}