#pragma once
#include<iostream>
#include<Windows.h>
using namespace std;
void FixConsoleWindow();
void GotoXY(int x, int y);
void SetTextColor(int color);
void SetConsoleFont(const wchar_t* font);