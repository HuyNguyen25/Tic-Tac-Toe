#include <iostream>
#include<conio.h>
#include<Windows.h>
#include<stdio.h>
#include"Console.h"
#include"Menu.h"

using namespace std;

int main() {
	wchar_t font[] = L"Consolas";
	system("color F0");
	FixConsoleWindow();
	SetConsoleFont(font);
	ShowMenu();
	return 0;
}