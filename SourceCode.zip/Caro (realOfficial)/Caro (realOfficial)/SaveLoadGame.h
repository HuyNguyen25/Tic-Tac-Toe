#pragma once
#include<iostream>
#include<string>
#include<conio.h>
#include<Windows.h>
#include<cstring>
#include<fstream>
#include<vector>
#include <cstdio>
#include"Point.h"
#include"Game.h"
#include"Console.h"

#define MAX_NUM_FILE 10
using namespace std;
//Save_Duy
bool SaveGame(_POINT** _A, bool* _TURN, int* XScore, int* XStep, int* OScore, int* OStep);
string UpdateFilesMenu();
string FileNameGenerator();
string TimeGenerator();
void WriteFileList(ofstream& file, vector<string>& FileList);
void SaveGameState(string fileName, _POINT** _A, bool* _TURN, int* XScore, int* XStep, int* OScore, int* OStep);
void SaveCurrentTurn(ofstream& fout, bool* _TURN);
void SaveScoreStep(ofstream& fout, int* score, int* step);
void SaveEachCell(ofstream& fout, _POINT* _A);

//Load_Huy
void UpdateLoadMenu(vector<string>& menu, string delFile);
void ReadEachCell(ifstream& fi, _POINT& A);
void ReadFileTurn(ifstream& fi, bool& _TURN);
void ReadFileScoreStep(ifstream& fi, int& score, int& step);
void ReadFileBoard(ifstream& fi,_POINT **&arr,bool& turn, int &xscore, int &xstep, int &oscore, int &ostep);
void ReadFileList(ifstream& fi,vector<string>&s);
void DrawLoadBanner();
void DrawLoadTutorial();
void DrawLoadSymbol();
void DrawLoadInterface();
string ShowLoadMenu();

