#pragma once
#include<iostream>
#include<string>
#include<conio.h>
#include<Windows.h>
#include"Console.h"

using namespace std;
void ShowSettingBanner();
void ShowSettingTutorial();
void DrawOnOffButton(int x, int y);
void DrawMusicNote();
void ShowSettingMenu();


