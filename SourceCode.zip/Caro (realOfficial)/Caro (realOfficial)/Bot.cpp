#include "Bot.h"

bool AlreadyChecked(_POINT** _A, int i, int j)
{
    return(_A[i][j].c != 0);
}

bool CheckSurrounding(_POINT** _A, int i, int j)
{
    for (int u = -1; u <= 1; u++) {
        for (int v = -1; v <= 1; v++) {
            int RowIndex = i + u;
            int ColIndex = j + v;
            if (RowIndex == i && ColIndex == j)
                continue;
            if (RowIndex >= 0 && ColIndex >= 0 && RowIndex < BOARD && ColIndex < BOARD) {
                if (_A[RowIndex][ColIndex].c != 0)
                    return false;
            }
        }
    }
    return true;
}

int HorizontallyCheck_Left(_POINT** _Arr, int i, int j, int c) {
    int RIndex = i;
    int CIndex = j - 1;
    int count = 0;
    while (CIndex >= 0) {
        if (_Arr[RIndex][CIndex].c != c)
            break;
        count++;
        CIndex--;
    }
    return count;
}

int HorizontallyCheck_Right(_POINT** _Arr, int i, int j, int c) {
    int RIndex = i;
    int CIndex = j + 1;
    int count = 0;
    while (CIndex < BOARD) {
        if (_Arr[RIndex][CIndex].c != c)
            break;
        count++;
        CIndex++;
    }
    return count;
}

int VerticallyCheck_Up(_POINT** _Arr, int i, int j, int c) {
    int RIndex = i - 1;
    int CIndex = j;
    int count = 0;
    while (RIndex >= 0) {
        if (_Arr[RIndex][CIndex].c != c)
            break;
        count++;
        RIndex--;
    }
    return count;
}

int VerticallyCheck_Down(_POINT** _Arr, int i, int j, int c) {
    int RIndex = i + 1;
    int CIndex = j;
    int count = 0;
    while (RIndex < BOARD) {
        if (_Arr[RIndex][CIndex].c != c)
            return count;
        count++;
        RIndex++;
    }
    return count;
}

int RightUpCheck(_POINT** _Arr, int i, int j, int c) {
    int RIndex = i - 1;
    int CIndex = j + 1;
    int cnt = 0;
    while (RIndex >= 0 && CIndex < BOARD) {
        if (_Arr[RIndex][CIndex].c != c) {
            break;
        }
        cnt++;
        RIndex--;
        CIndex++;
    }
    return cnt;
}

int LeftUpCheck(_POINT** _Arr, int i, int j, int c) {
    int RIndex = i - 1;
    int CIndex = j - 1;
    int cnt = 0;
    while (RIndex >= 0 && CIndex >= 0) {
        if (_Arr[RIndex][CIndex].c != c) {
            break;
        }
        cnt++;
        RIndex--;
        CIndex--;
    }
    return cnt;
}

int RightDownCheck(_POINT** _Arr, int i, int j, int c)
{
    int cnt = 0;
    int RIndex = i + 1;
    int CIndex = j + 1;
    while (RIndex < BOARD && CIndex < BOARD) {
        if (_Arr[RIndex][CIndex].c != c)
            break;
        cnt++;
        RIndex++;
        CIndex++;
    }
    return cnt;
}

int LeftDownCheck(_POINT** _Arr, int i, int j, int c)
{
    int cnt = 0;
    int RIndex = i + 1;
    int CIndex = j - 1;
    while (RIndex < BOARD && CIndex >= 0) {
        if (_Arr[RIndex][CIndex].c != c)
            break;
        cnt++;
        RIndex++;
        CIndex--;
    }
    return cnt;
}

static bool CheckEmptyEndFromCell(_POINT** _Arr, int i, int j, int mode, int amount) {/*1 up 2 rightup 3 right 4 rightdown 5 down 6 leftdown 7 left 8 leftup*/
    switch (mode) {
    case 1:
        i -= (amount + 1);
        break;
    case 2:
        i -= (amount + 1);
        j += (amount + 1);
        break;
    case 3:
        j += (amount + 1);
        break;
    case 4:
        i += (amount + 1);
        j += (amount + 1);
        break;
    case 5:
        i += (amount + 1);
        break;
    case 6:
        i += (amount + 1);
        j -= (amount + 1);
        break;
    case 7:
        j -= (amount + 1);
        break;
    case 8:
        i -= (amount + 1);
        j -= (amount + 1);
        break;
    }
    return (i >= 0 && j >= 0 && i < BOARD&& j < BOARD&& _Arr[i][j].c == 0);
}

int Optimize(_POINT** _Arr, int i, int j, int c) {

    int LeftUp = LeftUpCheck(_Arr, i, j, c);
    int RightUp = RightUpCheck(_Arr, i, j, c);
    int Up = VerticallyCheck_Up(_Arr, i, j, c);
    int Left = HorizontallyCheck_Left(_Arr, i, j, c);
    int Right = HorizontallyCheck_Right(_Arr, i, j, c);
    int LeftDown = LeftDownCheck(_Arr, i, j, c);
    int Down = VerticallyCheck_Down(_Arr, i, j, c);
    int RightDown = RightDownCheck(_Arr, i, j, c);

    int subLeftUp = LeftUpCheck(_Arr, i - 1, j - 1, c);
    int subRightUp = RightUpCheck(_Arr, i - 1, j + 1, c);
    int subUp = VerticallyCheck_Up(_Arr, i - 1, j, c);
    int subLeft = HorizontallyCheck_Left(_Arr, i, j - 1, c);
    int subRight = HorizontallyCheck_Right(_Arr, i, j + 1, c);
    int subLeftDown = LeftDownCheck(_Arr, i + 1, j - 1, c);
    int subDown = VerticallyCheck_Down(_Arr, i + 1, j, c);
    int subRightDown = RightDownCheck(_Arr, i + 1, j + 1, c);
    if (Up + Down >= 4
        || Left + Right >= 4
        || LeftDown + RightUp >= 4
        || LeftUp + RightDown >= 4)//Truong hop gan chien thang nhat hoac gan thua nhat
        return 4000;
    else if (Up + Down == 3 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down)
        || Left + Right == 3 && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right)
        || LeftDown + RightUp == 3 && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp)
        || LeftUp + RightDown == 3 && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        return 3900;//Truong hop X hoac O co the dat 4 quan co lien tiep nhat
    //Vi 1 duong 4 con lien tiep khong chan hoac 2 duong 4 con lien tiep khong chan deu chac chan thang nen bo qua truong hop 2 duong
    else if ((LeftUp == 3 && RightUp == 3)
        || (LeftUp == 3 && LeftDown == 3)
        || (RightDown == 3 && RightUp == 3)
        || (RightDown == 3 && LeftDown == 3)
        || (Up == 3 && LeftUp == 3)
        || (Up == 3 && RightUp == 3)
        || (Up == 3 && Left == 3)
        || (Up == 3 && Right == 3)
        || (Up == 3 && LeftDown == 3)
        || (Up == 3 && RightDown == 3)
        || (Left == 3 && LeftUp == 3)
        || (Left == 3 && RightUp == 3)
        || (Left == 3 && LeftDown == 3)
        || (Left == 3 && Down == 3)
        || (Left == 3 && RightDown == 3)
        || (Down == 3 && LeftDown == 3)
        || (Down == 3 && LeftUp == 3)
        || (Down == 3 && RightUp == 3)
        || (Down == 3 && Right == 3)
        || (Down == 3 && RightDown == 3)
        || (Right == 3 && LeftUp == 3)
        || (Right == 3 && LeftDown == 3)
        || (Right == 3 && RightUp == 3)
        || (Right == 3 && RightDown == 3))
        return 3800;//Truong hop 2 duong 4 co the bi chan
    else if ((LeftUp == 2 && RightUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp))
        || (LeftUp == 2 && LeftDown == 2 && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (RightDown == 2 && RightUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp))
        || (RightDown == 2 && LeftDown == 2 && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (Up == 2 && LeftUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp))
        || (Up == 2 && RightUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp))
        || (Up == 2 && Left == 2 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left))
        || (Up == 2 && Right == 2 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right))
        || (Up == 2 && LeftDown == 2 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (Up == 2 && RightDown == 2 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (Left == 2 && LeftUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp))
        || (Left == 2 && RightUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp))
        || (Left == 2 && LeftDown == 2 && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (Left == 2 && Down == 2 && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down))
        || (Left == 2 && RightDown == 2 && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (Down == 2 && LeftDown == 2 && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (Down == 2 && LeftUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp))
        || (Down == 2 && RightUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp))
        || (Down == 2 && Right == 2 && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right))
        || (Down == 2 && RightDown == 2 && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (Right == 2 && LeftUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp))
        || (Right == 2 && LeftDown == 2 && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (Right == 2 && RightUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp))
        || (Right == 2 && RightDown == 2) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        return 3000;//Truong hop 2 duong 3 khong chan

    else if ((Up == 1 && Down == 1 && LeftDown == 1 && RightUp == 1 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp))
        || (Up == 1 && Down == 1 && LeftUp == 1 && RightDown == 1 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (Left == 1 && Right == 1 && LeftUp == 1 && RightDown == 1 && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (Left == 1 && Right == 1 && LeftDown == 1 && RightUp == 1 && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp))
        || (LeftUp == 1 && RightUp == 1 && LeftDown == 1 && RightDown == 1 && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (Up == 1 && Down == 1 && Left == 1 && Right == 1 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right)))
        return 3000; //Truong hop 2 duong 3 khong chan
    else if ((subLeft == 2 && subLeftUp == 2 && CheckEmptyEndFromCell(_Arr, i, j - 1, 7, subLeft) && CheckEmptyEndFromCell(_Arr, i - 1, j - 1, 8, subLeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp))
        || (subLeft == 2 && subLeftDown == 2 && CheckEmptyEndFromCell(_Arr, i, j - 1, 7, subLeft) && CheckEmptyEndFromCell(_Arr, i + 1, j - 1, 6, subLeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (subLeft == 2 && subUp == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j, 1, subUp) && CheckEmptyEndFromCell(_Arr, i, j - 1, 7, subLeft) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left))
        || (subLeft == 2 && subDown == 2 && CheckEmptyEndFromCell(_Arr, i, j - 1, 7, subLeft) && CheckEmptyEndFromCell(_Arr, i + 1, j, 5, subDown) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left))
        || (subLeft == 2 && subRightUp == 2 && CheckEmptyEndFromCell(_Arr, i, j - 1, 7, subLeft) && CheckEmptyEndFromCell(_Arr, i - 1, j + 1, 2, subRightUp) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (subLeft == 2 && subRightDown == 2 && CheckEmptyEndFromCell(_Arr, i, j - 1, 7, subLeft) && CheckEmptyEndFromCell(_Arr, i + 1, j + 1, 4, subRightDown) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp))
        || (subLeftUp == 2 && subUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 8, subLeftUp) && CheckEmptyEndFromCell(_Arr, i - 1, j, 1, subUp) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up))
        || (subLeftUp == 2 && subRightUp == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j - 1, 8, subLeftUp) && CheckEmptyEndFromCell(_Arr, i - 1, j + 1, 2, subRightUp) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (subLeftUp == 2 && subRight == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j - 1, 8, subLeftUp) && CheckEmptyEndFromCell(_Arr, i, j + 1, 3, subRight) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp))
        || (subLeftUp == 2 && subDown == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j - 1, 8, subLeftUp) && CheckEmptyEndFromCell(_Arr, i + 1, j, 5, subDown) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (subLeftUp == 2 && subLeftDown == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j - 1, 8, subLeftUp) && CheckEmptyEndFromCell(_Arr, i + 1, j - 1, 6, subLeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (subUp == 2 && subRightUp == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j, 1, subUp) && CheckEmptyEndFromCell(_Arr, i - 1, j + 1, 2, subRightUp) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (subUp == 2 && subRight == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j, 1, subUp) && CheckEmptyEndFromCell(_Arr, i, j + 1, 3, subRight) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left))
        || (subUp == 2 && subRightDown == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j, 1, subUp) && CheckEmptyEndFromCell(_Arr, i + 1, j + 1, 4, subRightDown) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (subUp == 2 && subLeftDown == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j, 1, subUp) && CheckEmptyEndFromCell(_Arr, i + 1, j - 1, 6, subLeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (subRightUp == 2 && subRight == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j + 1, 2, subRightUp) && CheckEmptyEndFromCell(_Arr, i, j + 1, 3, subRight) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (subRightUp == 2 && subRightDown == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j + 1, 2, subRightUp) && CheckEmptyEndFromCell(_Arr, i + 1, j + 1, 4, subRightDown) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (subRightUp == 2 && subDown == 2 && CheckEmptyEndFromCell(_Arr, i - 1, j + 1, 2, subRightUp) && CheckEmptyEndFromCell(_Arr, i + 1, j, 5, subDown) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (subRight == 2 && subRightDown == 2 && CheckEmptyEndFromCell(_Arr, i, j + 1, 3, subRight) && CheckEmptyEndFromCell(_Arr, i + 1, j + 1, 4, subRightDown) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp))
        || (subRight == 2 && subDown == 2 && CheckEmptyEndFromCell(_Arr, i, j + 1, 3, subRight) && CheckEmptyEndFromCell(_Arr, i + 1, j, 5, subDown) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left))
        || (subRight == 2 && subLeftDown == 2 && CheckEmptyEndFromCell(_Arr, i, j + 1, 3, subRight) && CheckEmptyEndFromCell(_Arr, i + 1, j - 1, 6, subLeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown))
        || (subRightDown == 2 && subDown == 2 && CheckEmptyEndFromCell(_Arr, i + 1, j + 1, 4, subRightDown) && CheckEmptyEndFromCell(_Arr, i + 1, j, 5, subDown) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (subRightDown == 2 && subLeftDown == 2 && CheckEmptyEndFromCell(_Arr, i + 1, j + 1, 4, subRightDown) && CheckEmptyEndFromCell(_Arr, i + 1, j - 1, 6, subLeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        || (subDown == 2 && subLeftDown == 2 && CheckEmptyEndFromCell(_Arr, i + 1, j, 5, subDown) && CheckEmptyEndFromCell(_Arr, i + 1, j - 1, 6, subLeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down) && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp) && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown)))
        return 3000;
    /*Truong hop dac biet nhu:  o
                                o

                                o  o o */
    else if (Up + Down == 2 && CheckEmptyEndFromCell(_Arr, i, j, 1, Up) && CheckEmptyEndFromCell(_Arr, i, j, 5, Down)
        || Left + Right == 2 && CheckEmptyEndFromCell(_Arr, i, j, 7, Left) && CheckEmptyEndFromCell(_Arr, i, j, 3, Right)
        || LeftDown + RightUp == 2 && CheckEmptyEndFromCell(_Arr, i, j, 6, LeftDown) && CheckEmptyEndFromCell(_Arr, i, j, 2, RightUp)
        || LeftUp + RightDown == 2 && CheckEmptyEndFromCell(_Arr, i, j, 8, LeftUp) && CheckEmptyEndFromCell(_Arr, i, j, 4, RightDown))
        return 2900;//Truong hop 1 duong 3 khong chan
    else if (Up + Down == 3
        || Left + Right == 3
        || LeftDown + RightUp == 3
        || LeftUp + RightDown == 3)
        return 2900;//Truong hop 1 duong 4 co chan
    else
        return (LeftUp * LeftUp) + (Up * Up) + (RightUp * RightUp)
        + (Left * Left) + (Right * Right) + (LeftDown * LeftDown) + (Down * Down) + (RightDown * RightDown)+100;
}

int Min(int Weight[BOARD][BOARD], int& im, int& jm)
{
    int result = Weight[0][0];
    im = 0;
    jm = 0;
    for (int i = 0; i < BOARD; i++) {
        for (int j = 0; j < BOARD; j++) {
            if (Weight[i][j] < result) {
                result = Weight[i][j];
                im = i;
                jm = j;
            }
        }
    }
    return result;
}

int Max(int Weight[BOARD][BOARD], int& iM, int& jM)
{
    int result = Weight[0][0];
    iM = 0;
    jM = 0;
    for (int i = 0; i < BOARD; i++) {
        for (int j = 0; j < BOARD; j++) {
            if (Weight[i][j] > result) {
                result = Weight[i][j];
                iM = i;
                jM = j;
            }
        }
    }
    return result;
}

int Calculator(_POINT** _A, int i, int j, int c) {
    int sum = 0;
    int LeftUp = LeftUpCheck(_A, i, j, c);
    int RightUp = RightUpCheck(_A, i, j, c);
    int Up = VerticallyCheck_Up(_A, i, j, c);
    int Left = HorizontallyCheck_Left(_A, i, j, c);
    int Right = HorizontallyCheck_Right(_A, i, j, c);
    int LeftDown = LeftDownCheck(_A, i, j, c);
    int Down = VerticallyCheck_Down(_A, i, j, c);
    int RightDown = RightDownCheck(_A, i, j, c);

    sum = (LeftUp * LeftUp) + (Up * Up) + (RightUp * RightUp)
        + (Left * Left) + (Right * Right) + (LeftDown * LeftDown) + (Down * Down) + (RightDown * RightDown);

    return sum;
}

int CalculateWeight_Easy(_POINT** _A, int i, int j) {
    int SumX = 0, SumO = 0;
    //SumX
    SumX = -Calculator(_A, i, j, -1);

    //SumO
    SumO = Calculator(_A, i, j, 1);

    if (abs(SumO) >= abs(SumX))
        return SumO;

    return SumX;
}

int CalculateWeight_Hard(_POINT** _A, int i, int j) {
    int SumX = 0, SumO = 0;

    //SumX
    SumX = -Optimize(_A, i, j, -1);

    //SumO
    SumO = Optimize(_A, i, j, 1);

    if (abs(SumO) >= abs(SumX))
        return SumO;

    return SumX;
}

void InitWeightArr(int Weight[BOARD][BOARD], _POINT** _A, int mode) {
    for (int i = 0; i < BOARD; i++) {
        for (int j = 0; j < BOARD; j++) {
            if (AlreadyChecked(_A, i, j))
                Weight[i][j] = 0;
            else if (CheckSurrounding(_A, i, j))
                Weight[i][j] = 0;
            else {
                if(mode==1)
                Weight[i][j] =CalculateWeight_Easy(_A,i,j);
                else {
                    Weight[i][j] = CalculateWeight_Hard(_A, i, j);
                    if (abs(Weight[i][j]) != 4000 && (i == 0 || j == 0 || i == BOARD - 1 || j == BOARD - 1))
                        Weight[i][j] -= (Weight[i][j] > 0) ? 90 : -90;
                }
            }
        }
    }
}

void FindPositionForBot(int Weight[BOARD][BOARD], _POINT** _A, int& RIndex, int& CIndex, int mode) {
    InitWeightArr(Weight, _A,mode);
    int im, jm, iM, jM;
    int maxW = Max(Weight, iM, jM);
    int minW = Min(Weight, im, jm);
    if (abs(maxW) >= abs(minW))
    {
        RIndex = iM;
        CIndex = jM;
        return;
    }
    RIndex = im;
    CIndex = jm;
}