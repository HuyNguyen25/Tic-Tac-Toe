#pragma once
#include<iostream>
#include<conio.h>
#include<Windows.h>
#include "Console.h"
#include "Menu.h"
#include <fstream>
#include <string>

void resetCounter(int color[], int& counter);
void resetScreen();
void DrawTutorialsBorder();
void printTutorialsGuide();
void ShowTutorials();
void ShowTutorialsTexts();
void ViewInfo();
void Controls();
void EndRules();