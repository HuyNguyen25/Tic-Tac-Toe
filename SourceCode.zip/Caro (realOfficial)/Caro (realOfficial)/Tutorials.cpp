#include "Tutorials.h"

string options[] = { "BACK", "NEXT" };
int color[] = { 226,240 };
int counter = 1;
char _KEY;

void resetCounter(int color[], int& counter) {
	color[0] = 226;
	color[1] = 240;
	counter = 1;
}

void resetScreen() {
	system("cls");
	ShowBanner();
	DrawTutorialsBorder();
	printTutorialsGuide();
	resetCounter(color, counter);
	int j;
	for (int i = 0; i < 2; i++) {
		j = (i == 0) ? 35 : 81;
		GotoXY(j, 22);
		SetTextColor(color[i]);
		cout << options[i];
	}
}

void DrawTutorialsBorder() {// Left 35 Top 12 Right 88 Bottom 24
	SetTextColor(243);
	GotoXY(33, 12);
	cout << (char)201;
	for (int i = 0; i < 52; i++) {
		if (i == 23) {
			cout << "TUTORIAL";
			i += 7;
		}
		else
			cout << (char)205;
	}
	cout << (char)187;

	for (int i = 0; i < 11; i++) {
		GotoXY(33, 13 + i);
		cout << (char)186;
		for (int i = 0; i < 52; i++)
			cout << " ";
		cout << (char)186;
	}
	GotoXY(33, 24);
	cout << (char)200;
	for (int i = 0; i < 52; i++)
		cout << (char)205;
	cout << (char)188;
	SetTextColor(240);
}

void printTutorialsGuide() {
	SetTextColor(243);
	GotoXY(55, 26);
	cout << (char)16 << " A: GO LEFT";
	GotoXY(55, 27);
	cout << (char)16 << " D: GO RIGHT";
	GotoXY(55, 28);
	cout << (char)16 << " ENTER: SELECT";
}

void ShowTutorials() {
	system("cls");
	ShowBanner();
	DrawTutorialsBorder();
	ShowTutorialsTexts();
	printTutorialsGuide();
}

void ShowTutorialsTexts() {
	int j;
	int page = 0; // Mac dinh page = 0 neu duoc goi tu ham ShowTutorialsTexts

	for (; true;) {

		for (int i = 0; i < 2; i++) {
			j = (i == 0) ? 35 : 81;
			GotoXY(j, 22);
			SetTextColor(color[i]);
			cout << options[i];
		}
		for (int i = 0; i < 2; i++)
			color[i] = 240;

		if (page == 0) 
		{
			ViewInfo(); //Chay trang 1 neu duoc goi tu ham chinh
			page++;
		}

		_KEY = toupper(_getch());
		switch (_KEY) {
		case 'A':
			counter=1;
			for (int i = 0; i < 2; i++)
				color[i] = 240;
			PlaySound(TEXT("Sound/MovingSound.wav"), NULL, SND_ASYNC);
			break;

		case 'D':
			counter=2;
			for (int i = 0; i < 2; i++)
				color[i] = 240;
			PlaySound(TEXT("Sound/MovingSound.wav"), NULL, SND_ASYNC);
			break;

		case 13:
			options[1] = "";
			options[1] = "NEXT";
			switch (counter) {
			case 1: // An Back
				PlaySound(TEXT("Sound/MovingSound.wav"), NULL, SND_ASYNC);
				switch (page) {
				case 1:
					return;
				case 2:
					ViewInfo();
					break;
				case 3:
					Controls();
					break;
				}
				page--; // page-=1 neu nguoi dung an Back
				
				break;
			case 2: // An Next
				PlaySound(TEXT("Sound/MovingSound.wav"), NULL, SND_ASYNC);
				switch (page) {
				case 1:
					Controls();
					break;
				case 2:
					EndRules();
					break;
				case 3:
					SetTextColor(240);
					return;
				}
				page++; // page+=1 neu nguoi dung an Next
				break;
			}
			break;
		}

		color[counter - 1] = 226;
	}
}

void ViewInfo() {
	SetTextColor(240);
	resetScreen();
	int row = 16;
	string line;
	ifstream fIn;
	fIn.open("Tutorial_1.txt", ios_base::in);

	while (getline(fIn, line)) {
		GotoXY(37, row++);
		cout << line;
	}

	if (fIn) fIn.close();
	return;

}

void Controls() {
	SetTextColor(240);
	resetScreen();
	int row = 14;
	string line;
	ifstream fIn;
	fIn.open("Tutorial_2.txt", ios_base::in);

	while (getline(fIn, line)) {
		GotoXY(37, row++);
		cout << line;
	}

	if (fIn) fIn.close();

	return;
}

void EndRules() {
	SetTextColor(240);
	options[1] = "";
	options[1] = "END";
	resetScreen();
	int row = 14;
	string line;
	ifstream fIn;
	fIn.open("Tutorial_3.txt", ios_base::in);

	while (getline(fIn, line)) {
		GotoXY(37, row++);
		cout << line;
	}

	if (fIn) fIn.close();
	return;
}