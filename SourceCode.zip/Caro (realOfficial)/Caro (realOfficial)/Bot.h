#pragma once
#include<iostream>
#include<cmath>
#include"Game.h"
#include"Point.h"

#define BOARD 12 

#define leftup(i,j) (i>=0 && j>=0)?true:false
#define up(i,j) (i>=0)?true:false
#define rightup(i,j) (i>=0&&j<BOARD)?true:false
#define left(i,j) (j>=0)?true:false
#define right(i,j) (j<BOARD)?true:false
#define leftdown(i,j) (i<BOARD&&j>=0)?true:false
#define down(i,j) (i<BOARD)?true:false
#define rightdown(i,j) (i<BOARD &&j<BOARD)?true:false

bool AlreadyChecked(_POINT** _A, int i, int j);
bool CheckSurrounding(_POINT** _A, int i, int j);
int HorizontallyCheck_Left(_POINT** _Arr, int i, int j, int c);
int HorizontallyCheck_Right(_POINT** _Arr, int i, int j, int c);
int VerticallyCheck_Up(_POINT** _Arr, int i, int j, int c);
int VerticallyCheck_Down(_POINT** _Arr, int i, int j, int c);
int RightUpCheck(_POINT** _Arr, int i, int j, int c);
int LeftUpCheck(_POINT** _Arr, int i, int j, int c);
int RightDownCheck(_POINT** _Arr, int i, int j, int c);
int LeftDownCheck(_POINT** _Arr, int i, int j, int c);
int Optimize(_POINT** _Arr, int i, int j, int c);
int Min(int Weight[BOARD][BOARD], int& im, int& jm);
int Max(int Weight[BOARD][BOARD], int& iM, int& jM);
int Calculator(_POINT** _A, int i, int j, int c);
int CalculateWeight_Easy(_POINT** _A, int i, int j);
int CalculateWeight_Hard(_POINT** _A, int i, int j);
void InitWeightArr(int Weight[BOARD][BOARD], _POINT** _A, int mode);
void FindPositionForBot(int Weight[BOARD][BOARD], _POINT** _A, int& RIndex, int& CIndex, int mode);