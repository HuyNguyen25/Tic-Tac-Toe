#pragma once
#pragma pack (1)
struct _POINT { int x, y, c; };
