#include "Credits.h"

void DrawCreditsBorder() {// Left 35 Top 12 Right 87 Bottom 24
	SetTextColor(243);
	GotoXY(34, 12);
	cout << (char)201;
	for (int i = 0; i < 52; i++) {
		if (i == 22) {
			cout << "CREDITS";
			i += 6;
		}
		else
			cout << (char)205;
	}
	cout << (char)187;

	for (int i = 0; i < 11; i++) {
		GotoXY(34, 13 + i);
		cout << (char)186;
		for (int i = 0; i < 52; i++)
			cout << " ";
		cout << (char)186;
	}
	
	GotoXY(34, 24);
	cout << (char)200;
	for (int i = 0; i < 52; i++)
		cout << (char)205;
	cout << (char)188;
	SetTextColor(240);
}

void PrintCreditsTutorial() {
	SetTextColor(243);
	GotoXY(49,25);
	cout << "BACKSPACE: BACK TO MENU";
	SetTextColor(240);
}

void ShowCredits() {
	char _KEY;
	system("cls");
	ShowBanner();
	DrawCreditsBorder();
	
	//Viet credits
	string credits[] = { "Members list: "
		,"22127156 Nguyen Phuc Huy" 
		,"22127090 Van Diep Bao Duy","22127483 Nguyen Huynh Minh Quang"
		,"Special Thank To GVHD: TS. Truong Toan Thinh"};
	int nCredits = 5;
	
		for (int i = 18; i >= 14; i--) {
			
			for (int j = 0; j <= 2 * nCredits + 8 - i; j++)
			{
				GotoXY(40, i+j);
				cout << credits[j] << endl;
			}
				
			Sleep(1000);
		}
		PrintCreditsTutorial();
		do {
			
		_KEY = toupper(_getch());
		
		if (_KEY == 8)
		{
			return;
		}
	} while (true);
}