#pragma once
#include<iostream>
#include<string>
#include<conio.h>
#include<Windows.h>
#include<fstream>
#include<malloc.h>
#include "SaveLoadGame.h"
#include"Console.h"
#include"Point.h"
#include"Bot.h"
using namespace std;
#define BOARD_SIZE 12 
#define LEFT 30
#define TOP 3

void DrawTurnFrame();
void DrawScoreFrame();
void DrawGuideFrame();
void DrawBotIcon();
void DrawMinionIcon();
void DrawInterface(void (*DrawMode)());

void UpdateXStep();
void UpdateOStep();
void UpdateXScore();
void UpdateOScore();
void UpdateTurn(bool turn);
void UpdateWinner(bool turn);

void DrawX(int left, int top);
void DrawO(int left, int top);

void DrawXWon();
void DrawOWon();
void DrawDraw();
void DrawBoard();

void ResetData();
void StartGame(void (*DrawMode)());
int AskContinue();
void GarbageCollect();
void ExitGame();

void MoveLeft();
void MoveRight();
void MoveDown();
void MoveUp();

int CheckBoard(int x, int y);

bool FullMatrix();
bool EmptyMatrix();

bool WinnerAppears();
int TestBoard();
int ProcessFinish(int WhoWin);

void NewGame(string file);
void NewGame_Bot(int mode);