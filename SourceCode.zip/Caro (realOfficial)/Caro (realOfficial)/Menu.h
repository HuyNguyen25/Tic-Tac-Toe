#pragma once
#include<iostream>
#include<string>
#include<conio.h>
#include<Windows.h>
#include"Console.h"
#include"Tutorials.h"
#include"Credits.h"
#include"Game.h"
#include "SaveLoadGame.h"
#include"Setting.h"
using namespace std;
void ShowBanner();
void DrawMenuBorder();
void drawX(int color);
void drawY(int color);
void ShowMenu();
