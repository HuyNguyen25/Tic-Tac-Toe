﻿#include "Game.h"

struct _POINTARR {
    void* pRow[1];
};

static _POINTARR *arrStruct;
_POINT **_A;
bool _TURN=false;
int _COMMAND;
int _X, _Y;
int XScore=0, OScore=0,XStep,OStep;

static void GameErrorNotification() {
    system("cls");
    SetTextColor(244);
    GotoXY(9, 2); 
    cout << "EEEEEEEEEEEEEEEEEEEEEERRRRRRRRRRRRRRRRR   RRRRRRRRRRRRRRRRR        OOOOOOOOO     RRRRRRRRRRRRRRRRR   ";
    GotoXY(9, 3); 
    cout << "E::::::::::::::::::::ER::::::::::::::::R  R::::::::::::::::R     OO:::::::::OO   R::::::::::::::::R  ";
    GotoXY(9, 4); 
    cout << "E::::::::::::::::::::ER::::::RRRRRR:::::R R::::::RRRRRR:::::R  OO:::::::::::::OO R::::::RRRRRR:::::R ";
    GotoXY(9, 5); 
    cout << "EE::::::EEEEEEEEE::::ERR:::::R     R:::::RRR:::::R     R:::::RO:::::::OOO:::::::ORR:::::R     R:::::R";
    GotoXY(9, 6); 
    cout << "  E:::::E       EEEEEE  R::::R     R:::::R  R::::R     R:::::RO::::::O   O::::::O  R::::R     R:::::R";
    GotoXY(9, 7); 
    cout << "  E:::::E               R::::R     R:::::R  R::::R     R:::::RO:::::O     O:::::O  R::::R     R:::::R";
    GotoXY(9, 8); 
    cout << "  E::::::EEEEEEEEEE     R::::RRRRRR:::::R   R::::RRRRRR:::::R O:::::O     O:::::O  R::::RRRRRR:::::R ";
    GotoXY(9, 9); 
    cout << "  E:::::::::::::::E     R:::::::::::::RR    R:::::::::::::RR  O:::::O     O:::::O  R:::::::::::::RR  ";
    GotoXY(9, 10); 
    cout << "  E:::::::::::::::E     R::::RRRRRR:::::R   R::::RRRRRR:::::R O:::::O     O:::::O  R::::RRRRRR:::::R ";
    GotoXY(9, 11); 
    cout << "  E::::::EEEEEEEEEE     R::::R     R:::::R  R::::R     R:::::RO:::::O     O:::::O  R::::R     R:::::R";
    GotoXY(9, 12); 
    cout << "  E:::::E               R::::R     R:::::R  R::::R     R:::::RO:::::O     O:::::O  R::::R     R:::::R";
    GotoXY(9, 13); 
    cout << "  E:::::E       EEEEEE  R::::R     R:::::R  R::::R     R:::::RO::::::O   O::::::O  R::::R     R:::::R";
    GotoXY(9, 14); 
    cout << "EE::::::EEEEEEEE:::::ERR:::::R     R:::::RRR:::::R     R:::::RO:::::::OOO:::::::ORR:::::R     R:::::R";
    GotoXY(9, 15); 
    cout << "E::::::::::::::::::::ER::::::R     R:::::RR::::::R     R:::::R OO:::::::::::::OO R::::::R     R:::::R";
    GotoXY(9, 16); 
    cout << "E::::::::::::::::::::ER::::::R     R:::::RR::::::R     R:::::R   OO:::::::::OO   R::::::R     R:::::R";
    GotoXY(9, 17); 
    cout << "EEEEEEEEEEEEEEEEEEEEEERRRRRRRR     RRRRRRRRRRRRRRR     RRRRRRR     OOOOOOOOO     RRRRRRRR     RRRRRRR";
    SetTextColor(240);
}

static bool Init() {
    int sizePRow = BOARD_SIZE * sizeof(void*);
    int sizeRow = BOARD_SIZE * sizeof(_POINT);
    void* buff = calloc(sizePRow+BOARD_SIZE*sizeRow, 1);
    if (buff != NULL) {
        arrStruct = (_POINTARR*)buff;
        char* data = (char*)buff;
        data += sizePRow;
        arrStruct->pRow[0] = (void*)data;
        for (int i = 1; i < BOARD_SIZE; i++)
        {
            data += sizeRow;
            arrStruct->pRow[i] = (void*)data;
        }
        _A = (_POINT**)arrStruct;
        return true;
    }
    _A = (_POINT**)buff;
    return false;  
}

void DrawX(int left, int top) {
    //Xoa O
    GotoXY(left + 1, top+1);
    cout << "               ";
    GotoXY(left + 1, top+2);
    cout << "               ";
    GotoXY(left + 1, top+3);
    cout << "               ";
    GotoXY(left + 1, top+4);
    cout << "               ";
    GotoXY(left + 1, top+5);
    cout << "               ";

    //Ve X
    UINT oldcp = GetConsoleOutputCP();
    SetConsoleOutputCP(CP_UTF8);
    SetTextColor(244);

    GotoXY(left+3, top);
    cout << u8"██     ██";
    GotoXY(left + 3, top+1);
    cout << u8" ██   ██";
    GotoXY(left + 3, top+2);
    cout << u8"  ██ ██";
    GotoXY(left + 3, top+3);
    cout << u8"   ███";
    GotoXY(left + 3, top+4);
    cout << u8"  ██ ██";
    GotoXY(left + 3, top+5);
    cout << u8" ██   ██";
    GotoXY(left + 3, top+6);
    cout << u8"██     ██";

    SetConsoleOutputCP(oldcp);
    SetTextColor(240);    
}

void DrawO(int left, int top) {
    //Xoa X
    GotoXY(left + 2, top);
    cout << "              ";
    GotoXY(left + 3, top + 1);
    cout << "              ";
    GotoXY(left + 3, top + 2);
    cout << "             ";
    GotoXY(left + 3, top + 3);
    cout << "         ";
    GotoXY(left + 3, top + 4);
    cout << "          ";
    GotoXY(left + 3, top + 5);
    cout << "           ";
    GotoXY(left + 2, top + 6);
    cout << "             ";

    //Ve O
    UINT oldcp = GetConsoleOutputCP();
    SetConsoleOutputCP(CP_UTF8);
    SetTextColor(242);

    GotoXY(left+2, top);
    cout << u8" ████████";
    GotoXY(left + 2, top+1);
    cout << u8"███    ███";
    GotoXY(left + 2, top+2);
    cout << u8"███    ███";
    GotoXY(left + 2, top+3);
    cout << u8"███    ███";
    GotoXY(left + 2, top+4);
    cout << u8"███    ███";
    GotoXY(left + 2, top+5);
    cout << u8"███    ███";
    GotoXY(left + 2, top+6);
    cout << u8" ████████ ";

    SetConsoleOutputCP(oldcp);
    SetTextColor(240);
}

void UpdateTurn(bool turn) {
    if (turn)
        DrawX(7,7);
    else DrawO(8,7);
}

void DrawXWon() {
    SetTextColor(245);
    GotoXY(10,9);
    cout << "xxxxxxx      xxxxxxx     wwwwwww           wwwww           wwwwwww ooooooooooo   nnnn  nnnnnnnn    ";
    GotoXY(10, 10);
    cout << " x:::::x    x:::::x       w:::::w         w:::::w         w:::::woo:::::::::::oo n:::nn::::::::nn  ";
    GotoXY(10, 11);
    cout << "  x:::::x  x:::::x         w:::::w       w:::::::w       w:::::wo:::::::::::::::on::::::::::::::nn ";
    GotoXY(10, 12);
    cout << "   x:::::xx:::::x           w:::::w     w:::::::::w     w:::::w o:::::ooooo:::::onn:::::::::::::::n";
    GotoXY(10, 13);
    cout << "    x::::::::::x             w:::::w   w:::::w:::::w   w:::::w  o::::o     o::::o  n:::::nnnn:::::n";
    GotoXY(10, 14);
    cout << "     x::::::::x               w:::::w w:::::w w:::::w w:::::w   o::::o     o::::o  n::::n    n::::n";
    GotoXY(10, 15);
    cout << "     x::::::::x                w:::::w:::::w   w:::::w:::::w    o::::o     o::::o  n::::n    n::::n";
    GotoXY(10, 16);
    cout << "    x::::::::::x                w:::::::::w     w:::::::::w     o::::o     o::::o  n::::n    n::::n";
    GotoXY(10, 17);
    cout << "   x:::::xx:::::x                w:::::::w       w:::::::w      o:::::ooooo:::::o  n::::n    n::::n";
    GotoXY(10, 18);
    cout << "  x:::::x  x:::::x                w:::::w         w:::::w       o:::::::::::::::o  n::::n    n::::n";
    GotoXY(10, 19);
    cout << " x:::::x    x:::::x                w:::w           w:::w         oo:::::::::::oo   n::::n    n::::n";
    GotoXY(10, 20);
    cout << "xxxxxxx      xxxxxxx                www             www            ooooooooooo     nnnnnn    nnnnnn";
    SetTextColor(240);
}

void DrawOWon() {
    SetTextColor(245);
    GotoXY(12, 9);
    cout << "   ooooooooooo        wwwwwww           wwwww           wwwwwww ooooooooooo   nnnn  nnnnnnnn    ";
    GotoXY(12, 10);
    cout << " oo:::::::::::oo       w:::::w         w:::::w         w:::::woo:::::::::::oo n:::nn::::::::nn  ";
    GotoXY(12, 11);
    cout << "o:::::::::::::::o       w:::::w       w:::::::w       w:::::wo:::::::::::::::on::::::::::::::nn ";
    GotoXY(12, 12);
    cout << "o:::::ooooo:::::o        w:::::w     w:::::::::w     w:::::w o:::::ooooo:::::onn:::::::::::::::n";
    GotoXY(12, 13);
    cout << "o::::o     o::::o         w:::::w   w:::::w:::::w   w:::::w  o::::o     o::::o  n:::::nnnn:::::n";
    GotoXY(12, 14);
    cout << "o::::o     o::::o          w:::::w w:::::w w:::::w w:::::w   o::::o     o::::o  n::::n    n::::n";
    GotoXY(12, 15);
    cout << "o::::o     o::::o           w:::::w:::::w   w:::::w:::::w    o::::o     o::::o  n::::n    n::::n";
    GotoXY(12, 16);
    cout << "o::::o     o::::o            w:::::::::w     w:::::::::w     o::::o     o::::o  n::::n    n::::n";
    GotoXY(12, 17);
    cout << "o:::::ooooo:::::o             w:::::::w       w:::::::w      o:::::ooooo:::::o  n::::n    n::::n";
    GotoXY(12, 18);
    cout << "o:::::::::::::::o              w:::::w         w:::::w       o:::::::::::::::o  n::::n    n::::n";
    GotoXY(12, 19);
    cout << " oo:::::::::::oo                w:::w           w:::w         oo:::::::::::oo   n::::n    n::::n";
    GotoXY(12, 20);
    cout << "   ooooooooooo                   www             www            ooooooooooo     nnnnnn    nnnnnn";
    SetTextColor(240);
}

void DrawDraw() {
    SetTextColor(245);
    GotoXY(13, 7);
    cout << "            dddddddd                                                                         ";
    GotoXY(13, 8);
    cout << "            d::::::d                                                                         ";
    GotoXY(13, 9);
    cout << "            d::::::d                                                                         ";
    GotoXY(13, 10);
    cout << "            d:::::d                                                                          ";
    GotoXY(13, 11);
    cout << "    ddddddddd:::::drrrrr   rrrrrrrrr   aaaaaaaaaaaaawwwwwww           wwwww           wwwwwww";
    GotoXY(13, 12);
    cout << "  dd::::::::::::::dr::::rrr:::::::::r  a::::::::::::aw:::::w         w:::::w         w:::::w ";
    GotoXY(13, 13);
    cout << " d::::::::::::::::dr:::::::::::::::::r aaaaaaaaa:::::aw:::::w       w:::::::w       w:::::w  ";
    GotoXY(13, 14);
    cout << "d:::::::ddddd:::::drr::::::rrrrr::::::r         a::::a w:::::w     w:::::::::w     w:::::w   ";
    GotoXY(13, 15);
    cout << "d::::::d    d:::::d r:::::r     r:::::r  aaaaaaa:::::a  w:::::w   w:::::w:::::w   w:::::w    ";
    GotoXY(13, 16);
    cout << "d:::::d     d:::::d r:::::r     rrrrrrraa::::::::::::a   w:::::w w:::::w w:::::w w:::::w     ";
    GotoXY(13, 17);
    cout << "d:::::d     d:::::d r:::::r           a::::aaaa::::::a    w:::::w:::::w   w:::::w:::::w      ";
    GotoXY(13, 18);
    cout << "d:::::d     d:::::d r:::::r          a::::a    a:::::a     w:::::::::w     w:::::::::w       ";
    GotoXY(13, 19);
    cout << "d::::::ddddd::::::ddr:::::r          a::::a    a:::::a      w:::::::w       w:::::::w        ";
    GotoXY(13, 20);
    cout << " d:::::::::::::::::dr:::::r          a:::::aaaa::::::a       w:::::w         w:::::w         ";
    GotoXY(13, 21);
    cout << "  d:::::::::ddd::::dr:::::r           a::::::::::aa:::a       w:::w           w:::w          ";
    GotoXY(13, 22);
    cout << "   ddddddddd   dddddrrrrrrr            aaaaaaaaaa  aaaa        www             www           ";
    SetTextColor(240);    
}

void UpdateWinner(bool turn) {
    if (turn)
        DrawXWon();
    else DrawOWon();

    PlaySound(TEXT("Sound/WinningSound.wav"), NULL, SND_SYNC);
}

void DrawTurnFrame() {
    SetTextColor(243);
    GotoXY(3, TOP);
    cout << (char)201; // Top left
    for (int i = 0; i < 21; i++)
        cout << (char)205;
    cout << (char)187; // Top border + Top right
    
    GotoXY(3, TOP + 1); // Continue Right border
    cout << (char)186;
    for (int i = 0; i < 21; i++)
        cout << " ";
    cout << (char)186;
    
    GotoXY(3, TOP + 2); // Continue Left border
    cout << (char)186;
    for (int i = 0; i < 21; i++)
        cout << " ";
    cout << (char)186;
    
    GotoXY(3, TOP + 3); // Finish Text frame
    cout << (char)204;
    for (int i = 0; i < 21; i++)
        cout << (char)205;
    cout << (char)185;

    GotoXY(13, TOP + 2); // Text print
    cout << "TURN";

    for (int i = 0; i < 7; i++) { // Continue Left + Right border
        GotoXY(3, TOP + 4 + i);
        cout << (char)186;
        for (int i = 0; i < 21; i++)
            cout << " ";
        cout << (char)186;
    }
    
    GotoXY(3, TOP + 11); // Bottom border
    cout << (char)200;
    for (int i = 0; i < 21; i++)
        cout << (char)205;
    cout << (char)188;

    SetTextColor(240);
}

void DrawScoreFrame() {
    int top = TOP + 13;
    SetTextColor(243);

    GotoXY(3, top);
    cout << (char)201;
    for (int i = 0; i < 21; i++)
        cout << (char)205;
    cout << (char)187;

    GotoXY(3, top + 1);
    cout << (char)186;
    for (int i = 0; i < 21; i++)
        cout << " ";
    cout << (char)186;

    GotoXY(3, top + 2);
    cout << (char)186;
    for (int i = 0; i < 21; i++)
        cout << " ";
    cout << (char)186;

    GotoXY(3, top + 3);
    cout << (char)204;
    for (int i = 0; i < 21; i++)
        cout << (char)205;
    cout << (char)185;

    GotoXY(12, top + 2);
    cout << "SCORE";
    for (int i = 0; i < 7; i++) {
        GotoXY(3, top + 4 + i);
        cout << (char)186;
        for (int i = 0; i < 21; i++)
            cout << " ";
        cout << (char)186;
    }

    GotoXY(3, top + 11);
    cout << (char)200;
    for (int i = 0; i < 21; i++)
        cout << (char)205;
    cout << (char)188;

    SetTextColor(244);
    GotoXY(4, top + 5);
    cout << "Player X: "<<XScore;
    GotoXY(6, top + 6);
    cout << "Step: 0";
    SetTextColor(242);
    GotoXY(4, top + 7);
    cout << "Player O: "<<OScore;
    GotoXY(6, top + 8); 
    cout << "Step: 0";

    SetTextColor(240);
}

void DrawGuideFrame() {
    SetTextColor(253);
    GotoXY(89, 18);
    cout << "W:" << (char)30 << "   S:" << (char)31 << "   A:" << (char)17 << "   D:" << (char)16;
    GotoXY(90, 19);
    cout << "Enter: Check Board";
    GotoXY(91, 20);
    cout << "ESC: Back To Menu";
    GotoXY(93, 21);
    cout << "L: Save Game";
    GotoXY(86, 22);
    cout << "Go to Load Menu: Load Game";
    GotoXY(90, 23);
    cout << "Save / Load game is";
    GotoXY(87, 24);
    cout<<"Unavailable in PvBot mode";
    SetTextColor(240);
}

void DrawMinionIcon() {
    UINT oldcp = GetConsoleOutputCP();
    SetConsoleOutputCP(CP_UTF8);

    SetTextColor(240);
    GotoXY(84, 3);
    cout << u8"       ███████  ███████           ";
    GotoXY(84, 4);
    cout << u8"     ██       ██       ██         ";
    GotoXY(84, 5);
    cout << u8"         ████████████             ";

    SetTextColor(254);
    GotoXY(84, 6);
    cout << u8"        ███████████████           ";
    GotoXY(84, 7);
    cout << u8"     █████████████████████        ";
    GotoXY(84, 8);
    cout << u8"   █████████████████████████      ";
    GotoXY(85, 9);
    cout << u8" ███████████████████████████      ";

    SetTextColor(248);
    GotoXY(84, 10);
    cout << u8" ████████████████████████████     ";

    GotoXY(85, 11);
    cout << u8"████";

    SetTextColor(248);
    GotoXY(84, 11);
    cout << u8" █                            █   ";
    GotoXY(84, 12);
    cout << u8"██                            ██  ";
    GotoXY(84, 13);
    cout << u8"██                            ██  ";

    SetTextColor(247);
    GotoXY(84, 10);
    cout << u8"      ███████     ███████         ";
    GotoXY(84, 11);
    cout << u8"    ██       ██ ██       ██       ";
    GotoXY(84, 12);
    cout << u8"  ██    ██    ███    ██    ██     ";
    GotoXY(84, 13);
    cout << u8"  ██   █  █   ███   █  █   ██     ";
    GotoXY(84, 14);
    cout << u8"   ██   ██           ██   ██      ";

    SetTextColor(254);
    GotoXY(84, 10);
    cout << u8" █████";
    GotoXY(97, 10);
    cout << u8"█████";
    GotoXY(109, 10);
    cout << u8"█████";
    GotoXY(99, 11);
    cout << u8"█";
    GotoXY(84, 11);
    cout << u8" ███";
    GotoXY(111, 11);
    cout << u8"███";

    SetTextColor(248);
    GotoXY(85, 12);
    cout << u8"█";
    GotoXY(85, 13);
    cout << u8"██";
    GotoXY(85, 14);
    cout << u8"██";
    GotoXY(113, 12);
    cout << u8"█";
    GotoXY(112, 13);
    cout << u8"██";
    GotoXY(112, 14);
    cout << u8"██";

    SetTextColor(247);
    GotoXY(97, 14);
    cout << u8"█████";
    GotoXY(85, 15);
    cout << u8"  █████████████████████████       ";

    SetTextColor(254);
    GotoXY(85, 15);
    cout << u8"████";
    GotoXY(110, 15);
    cout << u8"████";
    GotoXY(85, 16);
    cout << u8"█████████████████████████████     ";

    SetConsoleOutputCP(oldcp);
    SetTextColor(240);
}

void DrawBotIcon() {
    UINT oldcp = GetConsoleOutputCP();
    SetConsoleOutputCP(CP_UTF8);

    SetTextColor(240);
    GotoXY(90, 3);
    cout << u8"     █████        ";
    GotoXY(90, 4);
    cout << u8"     █   █        ";
    GotoXY(90, 5);
    cout << u8"     █████        ";
    GotoXY(90, 6);
    cout << u8"       █          ";
    GotoXY(90, 7);
    cout << u8"  ██████████████  ";
    GotoXY(90, 8);
    cout << u8"  ██          ██  ";
    GotoXY(90, 9);
    cout << u8"  ██ ███  ███ ██  ";
    GotoXY(90, 10);
    cout << u8"  ██          ██  ";
    GotoXY(90, 11);
    cout << u8"  ██ ████████ ██  ";
    GotoXY(90, 12);
    cout << u8"  ██          ██  ";
    GotoXY(90, 13);
    cout << u8"  ██████████████  ";
    GotoXY(90, 14);
    cout << u8"██████████████████";
    GotoXY(90, 15);
    cout << u8"██  ██      ██  ██";
    GotoXY(90, 16);
    cout << u8"██████      ██████";

    SetTextColor(250);
    GotoXY(95, 9);
    cout << u8"███  ███";

    SetTextColor(249);
    GotoXY(95, 11);
    cout << u8"████████";

    SetTextColor(247);
    GotoXY(98, 8);
    cout << u8"████";
    GotoXY(98, 9);
    cout << u8"██";
    GotoXY(97, 10);
    cout << u8"████";
    GotoXY(98, 12);
    cout << u8"██";

    SetTextColor(248);
    GotoXY(101, 8);
    cout << u8"███";
    GotoXY(103, 9);
    cout << u8"█";
    GotoXY(101, 10);
    cout << u8"███";
    GotoXY(103, 11);
    cout << u8"█";
    GotoXY(100, 12);
    cout << u8"████";

    SetConsoleOutputCP(oldcp);
    SetTextColor(240);
}

void DrawInterface(void (*DrawIconMode)()) {
    DrawTurnFrame();
    DrawScoreFrame();
    DrawGuideFrame();
    DrawIconMode();
}

void UpdateXStep() {
    int top = TOP + 19;
    SetTextColor(244);
    GotoXY(6, top);
    cout << "Step: " << XStep;
    SetTextColor(240);
}

void UpdateOStep() {
    int top = TOP + 21;
    SetTextColor(242);
    GotoXY(6, top);
    cout << "Step: " << OStep;
    SetTextColor(240);
}

void UpdateXScore() {
    int top = TOP + 18;
    SetTextColor(244);
    GotoXY(4, top);
    cout << "Player X: " << XScore;
    SetTextColor(240);
}

void UpdateOScore() {
    int top = TOP + 20;
    SetTextColor(242);
    GotoXY(4, top);
    cout << "Player O: " << OScore;
    SetTextColor(240);
}

void ResetData() {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            _A[i][j].x = 4 * j + LEFT + 2;
            _A[i][j].y = 2 * i + TOP + 1;
            _A[i][j].c = 0;
        }
    }
    _TURN = !_TURN; _COMMAND = -1;
    _X = _A[0][0].x; _Y = _A[0][0].y;
    
    XStep = 0;
    OStep = 0;
}

void DrawBoard()
{
    int i, j;   
    GotoXY(LEFT, TOP);
    cout << (char)218;
    for (i = 0; i < BOARD_SIZE - 1; i++) {

        cout << (char)196 << (char)196 << (char)196 << (char)194;
    }
    cout << (char)196 << (char)196 << (char)196;
    cout << (char)191;
    cout << endl;

    for (i = 0; i < BOARD_SIZE - 1; i++)
    {
        GotoXY(LEFT, TOP + 1 + 2 * i);
        for (j = 0; j < BOARD_SIZE + 1; j++) {

            cout << (char)179 << "   ";
        }
        cout << endl;
        GotoXY(LEFT, TOP + 2 + 2 * i);
        cout << (char)195;
        for (j = 0; j < BOARD_SIZE - 1; j++) {
            cout << (char)196 << (char)196 << (char)196 << (char)197;
        }
        cout << (char)196 << (char)196 << (char)196;
        cout << (char)180 << endl;
    }

    GotoXY(LEFT, TOP + 2 * (BOARD_SIZE - 1) + 1);
    for (j = 0; j < BOARD_SIZE + 1; j++) {
        cout << (char)179 << "   ";
    }
    cout << endl;

    GotoXY(LEFT, TOP + 2 * (BOARD_SIZE));
    cout << (char)192;
    for (i = 0; i < BOARD_SIZE - 1; i++) {
        cout << (char)196 << (char)196 << (char)196 << (char)193;
    }
    cout << (char)196 << (char)196 << (char)196;
    cout << (char)217;
}

void StartGame(void (*DrawIconMode)()) {
    system("cls");
    ResetData();
    DrawInterface(DrawIconMode);
    UpdateTurn(_TURN);
    DrawBoard();
    GotoXY(_X, _Y);
}

int AskContinue() {
    GotoXY(0, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y + 2);
    cout<<"PRESS Y TO CONTINUE, OTHER KEY TO EXIT: ";
    return toupper(_getch());
}
void GarbageCollect() {
    if (_A != NULL)
        free((void*)_A);
}

void ExitGame() {
    XScore = 0;
    OScore = 0;
    _TURN = false;
    system("cls");
    GarbageCollect();
}

void MoveLeft() {
    if (_X > _A[0][0].x) {
        _X -= 4;
        GotoXY(_X, _Y);
    }
}

void MoveRight() {
    if (_X < _A[BOARD_SIZE - 1][BOARD_SIZE - 1].x)
    {
        _X += 4;
        GotoXY(_X, _Y);
    }
}

void MoveDown() {
    if (_Y < _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y)
    {
        _Y += 2;
        GotoXY(_X, _Y);
    }
}

void MoveUp() {
    if (_Y > _A[0][0].y)
    {
        _Y -= 2;
        GotoXY(_X, _Y);
    }
}

int CheckBoard(int x, int y) {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (_A[i][j].x == x && _A[i][j].y == y && _A[i][j].c == 0)
            {
                if (_TURN)
                    _A[i][j].c = -1;
                else _A[i][j].c = 1;
                return _A[i][j].c;
            }
        }
    }
    return 0;
}

bool FullMatrix() {
    for (int i = 0; i < BOARD_SIZE; i++)
        for (int j = 0; j < BOARD_SIZE; j++)
            if (_A[i][j].c == 0)
                return false;
    return true;
}

bool EmptyMatrix() {
    for (int i = 0; i < BOARD_SIZE; i++)
        for (int j = 0; j < BOARD_SIZE; j++)
            if (_A[i][j].c != 0)
                return false;
    return true;
}

static void flicker(_POINT arr[]) {
    PlaySound(TEXT("Sound/FlickerSound.wav"), NULL, SND_ASYNC);
    int color = 241;
    for (int time = 0; time < 30; time++) {
        if (color >= 254)
            color = 241;
        for (int i = 0; i < 5; i++) {
            GotoXY(arr[i].x, arr[i].y);
            if (arr[i].c == -1) {
                SetTextColor(color);
                cout << "X";
                SetTextColor(240);
            }
            else {
                SetTextColor(color);
                cout << "O";
                SetTextColor(240);
            }            
        }
        color++;
        Sleep(50);    
    }    
}

bool WinnerAppears() {
    _POINT win[5];
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (j < BOARD_SIZE - 4 && _A[i][j].c != 0 && _A[i][j].c == _A[i][j + 1].c && _A[i][j + 1].c == _A[i][j + 2].c
                && _A[i][j + 2].c == _A[i][j + 3].c && _A[i][j + 3].c == _A[i][j + 4].c) {
                
                for (int t = 0; t < 5; t++)
                    win[t] = _A[i][j + t];
                flicker(win);
                return true;
            }
                
            else if (i < BOARD_SIZE - 4 && _A[i][j].c != 0 && _A[i][j].c == _A[i + 1][j].c && _A[i + 1][j].c == _A[i + 2][j].c
                && _A[i + 2][j].c == _A[i + 3][j].c && _A[i + 3][j].c == _A[i + 4][j].c) {

                for (int t = 0; t < 5; t++)
                    win[t] = _A[i+t][j];
                flicker(win);
                return true;
            }
                
            else if (i < BOARD_SIZE - 4 && j < BOARD_SIZE - 4 && _A[i][j].c != 0 && _A[i][j].c == _A[i + 1][j + 1].c && _A[i + 1][j + 1].c == _A[i + 2][j + 2].c
                && _A[i + 2][j + 2].c == _A[i + 3][j + 3].c && _A[i + 3][j + 3].c == _A[i + 4][j + 4].c){
                
                for (int t = 0; t < 5; t++)
                    win[t] = _A[i+t][j + t];
                flicker(win);
                return true;
            }
                
            else if (j >= 4 && i < BOARD_SIZE - 4 && _A[i][j].c != 0 && _A[i][j].c == _A[i + 1][j - 1].c && _A[i + 1][j - 1].c == _A[i + 2][j - 2].c
                && _A[i + 2][j - 2].c == _A[i + 3][j - 3].c && _A[i + 3][j - 3].c == _A[i + 4][j - 4].c) {
               
                for (int t = 0; t < 5; t++)
                    win[t] = _A[i+t][j - t];
                flicker(win);
                return true;
            }              
        }
    }
    return false;
}

int TestBoard() {
    if (WinnerAppears()) {
        if (_TURN == true)
            return -1;
        else return 1;
    }
    else if (FullMatrix())
        return 0;
    else return 2;
}

int ProcessFinish(int WhoWin) {
    GotoXY(0, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y + 2);
    switch (WhoWin) {
    case -1:
        XScore++; 
        break;
    case 1:
        OScore++;
        break;
    case 0:
        //Khong ben nao tang diem
        break;
    case 2:
        _TURN = !_TURN;
        break;
    }
    UpdateXScore();
    UpdateOScore();
    UpdateTurn(_TURN);
    GotoXY(_X, _Y);
    return WhoWin;
}
static void PrintSavedBoard(_POINT**_A) {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            GotoXY(_A[i][j].x, _A[i][j].y);
            switch (_A[i][j].c) {
            case -1:
                SetTextColor(244);
                cout << "X";
                SetTextColor(240);
                break;
            case 1:
                SetTextColor(242);
                cout << "O";
                SetTextColor(240);
                break;
            }
        }
    }
}

void NewGame(string file) {
    system("color F0");
    if (!Init()) {// test
        GameErrorNotification();
        PlaySound(TEXT("Sound/ErrorSound.wav"), NULL, SND_ASYNC);
        Sleep(800);
        return;
    };

    void(*DrawIconMode)() = DrawMinionIcon;
    StartGame(DrawIconMode);

    if (file != "") {
        ifstream fi;
        fi.open(file, ios::in);
        ReadFileBoard(fi, _A, _TURN, XScore, XStep, OScore, OStep);
        if (fi) fi.close();

        UpdateTurn(_TURN);
        UpdateXScore();
        UpdateXStep();
        UpdateOScore();
        UpdateOStep();

        PrintSavedBoard(_A);

        _X = _A[5][5].x;
        _Y = _A[5][5].y;
        GotoXY(_X, _Y);// dua cursor vao giua ban co
    }

    bool validEnter = true;

    while (1) {
        _COMMAND = toupper(_getch());
        if (_COMMAND == 27)
        {
            ExitGame();
            return;
        }
        else if (_COMMAND == 'L')
        {
            if (!SaveGame(_A, &_TURN, &XScore, &XStep, &OScore, &OStep))
            {
                GotoXY(0, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y + 2);
                cout << "CAN NOT SAVE THE GAME, PLEASE GO TO LOAD MENU TO DELETE SOME FILES...";
                Sleep(1000);
                GotoXY(0, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y + 2);
                cout << "                                                                        ";
                GotoXY(_X, _Y);
            }
            else {
                GotoXY(0, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y + 2);
                cout << "SUCCESSFULLY SAVED";
                Sleep(1000);
                GotoXY(0, _A[BOARD_SIZE - 1][BOARD_SIZE - 1].y + 2);
                cout << "                                                                        ";
                GotoXY(_X, _Y);
            }
        }
        else if (_COMMAND == 'A') {
            MoveLeft();
            PlaySound(TEXT("Sound/MovingXOSound.wav"), NULL, SND_ASYNC);
        }
        else if (_COMMAND == 'S') {
            MoveDown();
            PlaySound(TEXT("Sound/MovingXOSound.wav"), NULL, SND_ASYNC);
        }
        else if (_COMMAND == 'D') {
            MoveRight();
            PlaySound(TEXT("Sound/MovingXOSound.wav"), NULL, SND_ASYNC);
        }
        else if (_COMMAND == 'W') {
            MoveUp();
            PlaySound(TEXT("Sound/MovingXOSound.wav"), NULL, SND_ASYNC);
        }
        else if (_COMMAND == 13) {
            switch (CheckBoard(_X, _Y)) {
            case -1:
                XStep++;
                UpdateXStep();
                GotoXY(_X, _Y);
                SetTextColor(244);
                cout << "X";
                SetTextColor(240);
                PlaySound(TEXT("Sound/TickXOSound.wav"), NULL, SND_ASYNC);//reset lai mau mac dinh de tranh loi mau
                break;
            case 1:
                OStep++;
                UpdateOStep();
                GotoXY(_X, _Y);
                SetTextColor(242);
                cout << "O";
                SetTextColor(240);
                PlaySound(TEXT("Sound/TickXOSound.wav"), NULL, SND_ASYNC);//reset lai mau mac dinh de tranh loi mau
                break;
            case 0:
                validEnter = false;
                break;

            }
            if (validEnter) {
                switch ((ProcessFinish(TestBoard())))
                {
                case 0:
                    DrawDraw();
                    PlaySound(TEXT("Sound/DrawSound.wav"), NULL, SND_ASYNC);
                    if (AskContinue() != 'Y') {
                        ExitGame();// trong ham ExitGame co reset XScore va OScore
                        return;
                    }
                    else StartGame(DrawIconMode);
                    break;
                case 1:
                case -1:
                    UpdateWinner(_TURN);
                    if (AskContinue() != 'Y') {
                        ExitGame();// trong ham ExitGame co reset XScore va OScore
                        return;
                    }
                    else StartGame(DrawIconMode);
                    break;
                }
            }
            validEnter = true;
        }
    }
}

void NewGame_Bot(int mode) {
    system("color F0");
    if (!Init()) {// test
        GameErrorNotification();
        PlaySound(TEXT("Sound/ErrorSound.wav"), NULL, SND_ASYNC);
        Sleep(800);
        return;
    };

    void (*DrawIconMode)() = DrawBotIcon;
    StartGame(DrawIconMode);

    bool validEnter = true;

    while (1) {
        _COMMAND = toupper(_getch());
        if (_COMMAND == 27)
        {
            ExitGame();
            return;
        }
        else if (_COMMAND == 'A') {
            MoveLeft();
            PlaySound(TEXT("Sound/MovingXOSound.wav"), NULL, SND_ASYNC);
        }
        else if (_COMMAND == 'S') {
            MoveDown();
            PlaySound(TEXT("Sound/MovingXOSound.wav"), NULL, SND_ASYNC);
        }
        else if (_COMMAND == 'D') {
            MoveRight();
            PlaySound(TEXT("Sound/MovingXOSound.wav"), NULL, SND_ASYNC);
        }
        else if (_COMMAND == 'W') {
            MoveUp();
            PlaySound(TEXT("Sound/MovingXOSound.wav"), NULL, SND_ASYNC);
        }
        else if (_COMMAND == 13) {
            switch (CheckBoard(_X, _Y)) {
            case -1: {
                XStep++;
                UpdateXStep();
                GotoXY(_X, _Y);
                SetTextColor(244);
                cout << "X";
                SetTextColor(240);
                PlaySound(TEXT("Sound/TickXOSound.wav"), NULL, SND_ASYNC);//reset lai mau mac dinh de tranh loi mau               
            }
                   break;

            case 0:
                validEnter = false;
                break;
            }

            if (validEnter) {
                switch ((ProcessFinish(TestBoard())))
                {
                case 0:
                    DrawDraw();
                    PlaySound(TEXT("Sound/DrawSound.wav"), NULL, SND_ASYNC);
                    if (AskContinue() != 'Y') {
                        ExitGame();// trong ham ExitGame co reset XScore va OScore
                        return;
                    }
                    else StartGame(DrawIconMode);
                    break;
                case 1:
                case -1:
                    UpdateWinner(_TURN);
                    if (AskContinue() != 'Y') {
                        ExitGame();// trong ham ExitGame co reset XScore va OScore
                        return;
                    }
                    else StartGame(DrawIconMode);
                    break;

                }
                Sleep(200);

                int Weight[BOARD_SIZE][BOARD_SIZE];
                int rowIndex, colIndex;
                FindPositionForBot(Weight, _A, rowIndex, colIndex, mode);
                int botX = _A[rowIndex][colIndex].x, botY = _A[rowIndex][colIndex].y;
                if (EmptyMatrix()) {
                    botX = _A[5][5].x;
                    botY = _A[5][5].y;
                }

                CheckBoard(botX, botY);
                OStep++;
                UpdateOStep();
                GotoXY(botX, botY);
                SetTextColor(242);
                cout << "O";
                SetTextColor(240);
                PlaySound(TEXT("Sound/TickXOSound.wav"), NULL, SND_ASYNC);
                switch ((ProcessFinish(TestBoard())))
                {
                case 0:
                    DrawDraw();
                    PlaySound(TEXT("Sound/DrawSound.wav"), NULL, SND_ASYNC);
                    if (AskContinue() != 'Y') {
                        ExitGame();// trong ham ExitGame co reset XScore va OScore
                        return;
                    }
                    else StartGame(DrawIconMode);
                    break;
                case 1:
                case -1:
                    UpdateWinner(_TURN);
                    if (AskContinue() != 'Y') {
                        ExitGame();// trong ham ExitGame co reset XScore va OScore
                        return;
                    }
                    else StartGame(DrawIconMode);
                    break;
                }
            }
            validEnter = true;
        }
    }
}
   













