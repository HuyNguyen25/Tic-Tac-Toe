#pragma once
#include<iostream>
#include<conio.h>
#include<Windows.h>
#include "Console.h"
#include "Menu.h"
#include<string>
void DrawCreditsBorder();
void PrintCreditsTutorial();
void ShowCredits();